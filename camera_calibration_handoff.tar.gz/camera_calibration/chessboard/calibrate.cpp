// calibrate.cpp —— 相机标定：棋盘格获取内参 + 畸变系数
// 用法：'c' 捕获，'s' 计算保存，'q' 退出。分辨率固定 640x480。
#include <opencv2/opencv.hpp>
#include <iostream>
#include <vector>

int main(int argc, char** argv) {
    cv::CommandLineParser parser(argc, argv,
        "{help h||}{camera|/dev/v4l/by-id/usb-HJ_USB_2.0_Camera_HJ_USB_2.0_Camera_SN0001-video-index0|Camera device}"
        "{square|0.025|Square side in meters}{output|chessboard_params.yaml|Output YAML}");
    if (parser.has("help")) {parser.printMessage();return 0;}
    // 棋盘格内部角点数 (列数, 行数)。9x6 = 每行 10 格、每列 7 格。
    cv::Size board_size(9, 6);
    // 每个方格的真实物理边长 (米)。用尺子量你的打印板！别用屏幕上的图。
    float square_size = parser.get<float>("square");
    std::string output = parser.get<std::string>("output");
    if (!parser.check() || !std::isfinite(square_size) || square_size<=0) {
        std::cerr << "参数错误：方格边长必须为正数（米）。" << std::endl; return 1;
    }

    // 显式选择设备；不回退其他摄像头，避免标定错设备。
    cv::VideoCapture cap(parser.get<std::string>("camera"), cv::CAP_V4L2);
    if (!cap.isOpened()) {
        std::cerr << "无法打开摄像头！请改上面的路径/编号（ls /dev/v4l/by-id/ 查）。" << std::endl;
        return -1;
    }

    // 固定 640x480：内参按像素算，标定分辨率和后面 PnP/视觉处理必须一致。
    cap.set(cv::CAP_PROP_FRAME_WIDTH,  640);
    cap.set(cv::CAP_PROP_FRAME_HEIGHT, 480);

    std::vector<cv::Point3f> obj_single_pattern;
    for (int i = 0; i < board_size.height; i++)
        for (int j = 0; j < board_size.width; j++)
            obj_single_pattern.push_back(cv::Point3f(j * square_size, i * square_size, 0.0f));

    std::vector<std::vector<cv::Point3f>> object_points;
    std::vector<std::vector<cv::Point2f>> image_points;

    cv::Mat frame, gray;
    cv::Size image_size;
    std::cout << "标定程序启动！把棋盘格对准镜头：" << std::endl;
    std::cout << "  'c' 捕获 | 's' 计算保存 | 'q' 退出（棋盘格需整块清晰入镜）" << std::endl;

    while (true) {
        cap >> frame;
        if (frame.empty()) break;

        if (image_size.empty()) {
            image_size = frame.size();
            if (image_size != cv::Size(640, 480)) {
                std::cerr << "警告：实际分辨率是 " << image_size.width << "x" << image_size.height
                          << "，不是 640x480，停止采集。" << std::endl;
                return 1;
            }
        }
        if (frame.size()!=image_size) {std::cerr << "分辨率改变，停止采集。\n";return 1;}

        cv::cvtColor(frame, gray, cv::COLOR_BGR2GRAY);
        std::vector<cv::Point2f> corners;
        bool found = cv::findChessboardCorners(gray, board_size, corners,
                                               cv::CALIB_CB_ADAPTIVE_THRESH | cv::CALIB_CB_NORMALIZE_IMAGE);

        cv::Mat display_frame = frame.clone();
        if (found) cv::drawChessboardCorners(display_frame, board_size, corners, found);

        std::string status = "Captured: " + std::to_string(image_points.size()) + " frames";
        cv::putText(display_frame, status, cv::Point(20, 30), cv::FONT_HERSHEY_SIMPLEX, 0.7,
                    cv::Scalar(0, 255, 0), 2);
        cv::imshow("Camera Calibration", display_frame);

        char key = (char)cv::waitKey(30);
        if (key == 'c' && found) {
            cv::cornerSubPix(gray, corners, cv::Size(11, 11), cv::Size(-1, -1),
                             cv::TermCriteria(cv::TermCriteria::EPS + cv::TermCriteria::COUNT, 30, 0.01));
            image_points.push_back(corners);
            object_points.push_back(obj_single_pattern);
            std::cout << "已捕获第 " << image_points.size() << " 组（覆盖不同角度/位置）" << std::endl;
        } else if (key == 's') {
            if (image_points.size() < 12) {
                std::cout << "少于 12 张，请继续多角度捕获。" << std::endl;
                continue;
            }
            break;
        } else if (key == 'q' || key == 27) {
            cap.release();
            return 0;
        }
    }

    if (image_points.size()<12) {std::cerr<<"采集中断，样本不足，不写参数。\n";return 1;}
    std::cout << "正在运行标定算法..." << std::endl;
    cv::Mat camera_matrix, dist_coeffs;
    std::vector<cv::Mat> rvecs, tvecs;
    double rep_error = cv::calibrateCamera(object_points, image_points, image_size,
                                           camera_matrix, dist_coeffs, rvecs, tvecs);

    std::vector<double> per_view;
    for (size_t i=0;i<image_points.size();++i) {
        std::vector<cv::Point2f> projected;
        cv::projectPoints(object_points[i],rvecs[i],tvecs[i],camera_matrix,dist_coeffs,projected);
        double rms=cv::norm(image_points[i],projected,cv::NORM_L2)/std::sqrt(projected.size());
        per_view.push_back(rms);
        std::cout<<"帧 "<<i<<" RMS="<<rms<<" px\n";
    }
    std::cout << "标定完成！重投影 RMS: " << rep_error << " 像素（不是单一合格判据，需实测验证）" << std::endl;
    std::cout << "内参 K:\n" << camera_matrix << std::endl;
    std::cout << "畸变:\n" << dist_coeffs << std::endl;

    cv::FileStorage fs(output, cv::FileStorage::WRITE);
    if (!fs.isOpened()) {std::cerr<<"无法写入 "<<output<<'\n';return 1;}
    fs << "camera_matrix" << camera_matrix;
    fs << "dist_coeffs" << dist_coeffs;
    fs << "image_width" << image_size.width << "image_height" << image_size.height;
    fs << "reprojection_rms" << rep_error;
    fs << "per_view_rms" << per_view;
    fs << "frame_count" << static_cast<int>(image_points.size());
    fs << "inner_corners_x" << board_size.width << "inner_corners_y" << board_size.height;
    fs << "square_length" << square_size;
    fs << "camera_device" << parser.get<std::string>("camera");
    fs.release();
    std::cout << "参数已保存到 " << output << std::endl;
    return 0;
}
