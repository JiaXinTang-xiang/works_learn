# 视觉/通信接入

`params/camera_params.yaml` 原样复制自当前 ChArUco 最新文件；仅用于本次 HJ 相机、640×480、
标定时焦距/成像模式。原文件无相机序列号等完整元数据，不能凭设备路径证明同一模式。
重新标定默认生成新文件，不自动替换随包快照。

| 字段 | 含义 |
| --- | --- |
| `camera_matrix` | K，3×3；`[fx,0,cx; 0,fy,cy; 0,0,1]`，单位像素 |
| `dist_coeffs` | 默认 5 项：`k1,k2,p1,p2,k3`，无量纲 |
| `image_width` / `image_height` | 当前为 640 / 480 |
| `reprojection_rms` | 所有参与求解角点的总体像素 RMS |
| `per_view_rms` | 新标定的逐帧 RMS；旧快照没有，不能补造 |
| `frame_count` | 求解最终保留帧数 |
| `square_length` / `marker_length` | 标定时的板子边长，米 |
| `board_layout` / `dictionary` | ChArUco 实物布局和字典标识 |

基本读取方式：

```cpp
cv::FileStorage fs("params/camera_params.yaml", cv::FileStorage::READ);
if (!fs.isOpened()) throw std::runtime_error("Cannot open camera params");
cv::Mat K, D;
int width=0, height=0;
fs["camera_matrix"] >> K;
fs["dist_coeffs"] >> D;
fs["image_width"] >> width;
fs["image_height"] >> height;
// 检查 K/D 有效及 frame.size()==cv::Size(width,height)。
// 原始像素角点：solvePnP(objectPoints, imagePoints, K, D, ...)。
```

若已去畸变且使用新内参 Knew，要用 **Knew + 零畸变** 对应校正后的像素，不能再用旧 D 校正一次。
不要缩放/裁剪图像后仍直接用未调整的 K。本包拒绝分辨率不一致，避免拉伸掩盖成像模式错误。

三角形模型物点单位米，`tvec=(X,Y,Z)` 单位也是**米**：x 向右、y 向下、z 光轴向前。
原点是两同心三角形公共重心。`Z` 为光轴深度，`range=norm(tvec)` 为光心到重心斜距。
若通信协议用毫米：`mm=m*1000`，不可把米当毫米。外边长 0.096 m，内边长 0.056 m，不是高度。
对称图案不能提供唯一朝向，不应直接将候选姿态当作唯一 yaw/roll。

目前程序输出终端/窗口，不发串口或 CAN。接已有通信工程前需确认字段、单位、坐标系、
有效标志及时间戳，再从 `triangle::Pose::tvec`、`rms` 取值打包。
检测失败应标记无效，不用旧值冒充新测量；阈值结合边缘质量、靶标像素大小和独立实测确定，
不能只凭低重投影 RMS 断言绝对距离正确。
