#include <opencv2/opencv.hpp>
#include <opencv2/aruco.hpp>
#include <filesystem>
#include <iostream>

int main(int argc, char** argv) {
    if (argc != 2) {std::cerr << "Usage: generate_boards package_directory\n"; return 1;}
    const std::filesystem::path root(argv[1]);
    // 640x480 画布；格子宽高严格相等。生成图片不是标定的实物尺寸。
    cv::Mat chess(480,640,CV_8UC1,cv::Scalar(255));
    constexpr int cell=54, left=50, top=51;
    for (int row=0;row<7;++row) for (int col=0;col<10;++col)
        if ((row+col)%2==0) chess(cv::Rect(left+col*cell,top+row*cell,cell,cell)).setTo(0);
    cv::Mat charuco(480,640,CV_8UC1,cv::Scalar(255));
    auto dictionary=cv::aruco::getPredefinedDictionary(cv::aruco::DICT_5X5_50);
    int id=0;
    for (int row=0;row<6;++row) for (int col=0;col<9;++col) {
        cv::Rect square(68+col*56,72+row*56,56,56);
        if ((row+col)%2==0) charuco(square).setTo(0);
        else {
            // 7 bit 单元(5x5 编码 + 两侧黑框)，42/56=.75；每单元正好 6 像素。
            cv::Mat marker;
            cv::aruco::drawMarker(dictionary,id++,42,marker,1);
            marker.copyTo(charuco(cv::Rect(square.x+7,square.y+7,42,42)));
        }
    }
    auto chessPath=root/"chessboard/chessboard_9x6_640x480.png";
    auto charucoPath=root/"charuco/charuco_9x6_5x5_640x480.png";
    if (!cv::imwrite(chessPath.string(),chess) || !cv::imwrite(charucoPath.string(),charuco)) return 1;
    std::cout<<chessPath<<"\n"<<charucoPath<<"\n";
}
