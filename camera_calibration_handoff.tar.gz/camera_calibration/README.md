# 相机标定与测距交接包（640×480）

整个文件夹可以独立交给同学/通信或视觉侧，不依赖原工程 `chapt5`，没有打包本机编译产物。
包含两种标定、匹配当前实物的布局、最新参数、三角形实时 PnP 和测试；原工程保留不动。

## 文件

| 路径 | 用途 |
| --- | --- |
| `chessboard/calibrate.cpp` | 普通棋盘，9×6 内角点，即 10×7 方格 |
| `chessboard/chessboard_9x6_640x480.png` | 640×480 普通棋盘打印图 |
| `charuco/charuco_calibrate.cpp` | 当前实物 ChArUco 标定、清晰度和覆盖提示、逐帧误差 |
| `charuco/physical_charuco_board.hpp` | 实物布局，修正 OpenCV 4.5.4 默认布局差异 |
| `charuco/charuco_9x6_5x5_640x480.png` | 匹配实物模型的 640×480 打印图，27 个标记 |
| `reference/my_charuco.jpg` | 原实物照片，仅供参考，不应当打印源图 |
| `params/camera_params.yaml` | 当前 HJ 相机最新 ChArUco 结果原样快照 |
| `validation/` | 三角形检测/PnP 源码及 `triangle_print.png` 打印源图 |
| `tools/generate_boards.cpp` | 棋盘图生成工具 |
| `tests/` | 布局、图片尺寸和三角形算法回归测试 |
| `INTEGRATION.md` | 参数字段、坐标系及通信/视觉接入说明 |

当前参数：640×480，22 帧，总体重投影 RMS 约 **0.791 px**；
`fx=310.2873, fy=309.8406, cx=317.9023, cy=246.1677`。
它不是通用参数，也不是精度已验收的保证。原快照无历史逐帧数据，不能事后恢复；新标定会保存逐帧误差。

## 编译

推荐 Linux/Ubuntu + g++、CMake、**OpenCV 4.5.4（含 contrib/aruco）**。
本包使用旧式 ArUco API，新版 OpenCV 兼容性需另测。

```bash
# 缺依赖时安装
sudo apt install build-essential cmake libopencv-dev libopencv-contrib-dev
cd camera_calibration
cmake -S . -B build
cmake --build build -j2
ctest --test-dir build --output-on-failure
```

搬到另一台机器后重新构建，勿复制旧 build，以便重设资源路径。后续命令均在包根目录执行。

## 相机、棋盘和实物尺寸

所有实时程序都打开相机，固定请求并检查 **640×480**，不符合就停止，不会强制拉伸。
默认设备是当前 HJ 外接相机；不自动回退内置相机。选择不同设备无需改源码：

```bash
ls -l /dev/v4l/by-id/
# 在运行命令后追加 --camera=/dev/video2 或实际 by-id 路径
```

同一时间只运行一个占相机的程序。相同分辨率仍需确保同一相机、焦距、裁剪/成像模式。

两张棋盘打印图均为 **640×480 像素画布**，通过留白适配，格子仍为正方形。
打印图像素大小与相机分辨率是两回事，并不要求二者相等才能标定。
保持打印纵横比；用尺子测实物，命令行尺寸单位为**米**：

- ChArUco：9×6 方格、`DICT_5X5_50`、27 标记。原值为格子 24 mm、标记黑色外框 18 mm。
  图片标记/格子比例为 0.75，整体缩放后需填写两个实际尺寸。
- 普通棋盘：9×6 内角点、10×7 方格；格子默认 25 mm，实际应测量。
- 三角形：外三条边**各 96 mm**，内三条边**各 56 mm**，同心同向、平整。
  尺寸指黑色外轮廓、白色内孔各自的边长，不是纸边或三角形高度。

ChArUco 打印图相对参考照片旋转了 180°，模型一致，实物使用不要求固定方向。
若需更高分辨率打印，可最近邻整数倍放大，别非等比拉伸。
不要用旧版 `board->draw()` 重印适配模型，底色可能不匹配；重生成两张图可用：

```bash
./build/generate_boards .
```

此命令会覆盖包内两张棋盘 PNG。三角形源图保持原比例，没有强制改成 640×480。

## 推荐：现有实物 ChArUco 标定

```bash
./build/charuco/charuco_calibrate --square=0.024 --marker=0.018 --output=charuco_params.yaml
```

点击窗口：`c` 捕获、`s` 计算保存、`q`/Esc 取消。每帧至少 20 角点、清晰度 >50 才捕获；
清晰度阈值是经验值，不能代替人眼。最低 10 帧，建议 **20～30 帧**：中心/四角/边缘、远近、
绕水平和竖直方向约 15°～40° 倾斜，停稳拍摄，避免反光弯纸和重复姿态。

`Coverage` 只统计已捕获帧：`pos` 是重心九宫格，`dist` 是包围面积三档，
`roll` 只是画面内旋转，**不代表三维倾角充分**。
沿用现有自动剔除：每次移除 RMS >1.5 px 的最差帧后重新标定，最低保留 10 帧。
剔除后仍可能有异常，也可能损失覆盖；剔除很多时应重采，不要把输出成功当作合格。

离线检查布局（不打开相机、不写标定参数）：

```bash
./build/charuco/charuco_calibrate --check-image=charuco/charuco_9x6_5x5_640x480.png
./build/charuco/charuco_calibrate --check-image=reference/my_charuco.jpg
```

## 可选：普通棋盘标定

```bash
./build/chessboard/calibrate --square=0.025 --output=chessboard_params.yaml
```

需 54 个内角点完整清晰入镜，不要求固定朝向。键位相同，最低 12 帧，建议 20～30 帧。

两套程序默认输出新文件，不覆盖随包参数快照。保存 K、畸变、图像尺寸、总体/逐帧 RMS、
帧数、板子参数及相机设备。不强制保存照片，便于轻量交接，因此不能重跑历史检测或核查原始图片。
如需严格审计，再增加原图/角点存档，而不是用低 RMS 替代独立验证。

## 打开摄像头实测三角形（不是模拟）

使用当前参数快照：

```bash
./build/triangle_pnp
```

刚重新标定后，必须显式指定新结果：

```bash
./build/triangle_pnp --params=charuco_params.yaml --side=0.096 --inner-side=0.056
```

按 `p` 打印当前 X/Y/Z、重心斜距和 6 点重投影 RMS/最大误差，`q` 退出。
绿线为轮廓拟合边、红点为角点、紫圈为模型重投影。内外 6 顶点需完整可见。
使用边缘/直线拟合，不需要二维码；等边图案有 120° 对称及平面位姿歧义，不输出唯一朝向。

例如实测**光心到三角形重心的斜距 50 cm**：

```bash
./build/triangle_pnp --params=charuco_params.yaml --distance=0.50
```

按 `p` 同时打印厘米/百分比误差。光心不一定在机壳表面，要考虑量尺起点误差。
不要用到纸边或沿桌面的距离代替斜距。`Z` 单独表示光轴深度，与偏心目标的斜距不同。
建议在 30/50/80 cm 等可清晰检测的距离、画面中心和边缘各测几次，按项目需求验收。

打印源图不是相机照片，不能直接测距，仅检查检测可运行：

```bash
./build/triangle_pnp --detect-only --image=validation/triangle_print.png
```

## 验收与交接注意

- 主点接近中心、fx/fy 接近 1 是合理性检查，不要手改 K 来凑数。
- `<0.5 px` 是可参考目标，不是通用合格线；看逐帧异常、覆盖与独立实测。
- 固定相机设置独立重采一组，比较参数稳定性和测距误差。
- 普通平面棋盘若整体等比缩放、尺寸填写错，主要影响平移尺度，不必然改变 K；
  非等比打印、ChArUco 格子/标记比例错则会污染几何。PnP 靶标尺寸错会直接引起距离比例错误。
- `tests` 的模拟投影只验证算法实现，不能验证真实相机标定精度。
- 交给通信侧的字段和单位见 `INTEGRATION.md`。本包没有擅自约定或实现串口/CAN 协议。
