#include "physical_charuco_board.hpp"
#include <opencv2/opencv.hpp>
#include <filesystem>
#include <iostream>
#include <stdexcept>

static void check(bool good,const char* message) {if (!good) throw std::runtime_error(message);}
int main(int argc,char** argv) {
    try {
        check(argc==2,"Need package directory");
        std::filesystem::path root(argv[1]);
        auto chess=cv::imread((root/"chessboard/chessboard_9x6_640x480.png").string(),0);
        check(chess.size()==cv::Size(640,480),"Chessboard must be 640x480");
        std::vector<cv::Point2f> corners;
        check(cv::findChessboardCorners(chess,{9,6},corners),"Must detect 54 chessboard corners");
        double dx=cv::norm(corners[1]-corners[0]),dy=cv::norm(corners[9]-corners[0]);
        check(std::abs(dx-dy)<.01,"Chessboard squares must not be stretched");
        auto image=cv::imread((root/"charuco/charuco_9x6_5x5_640x480.png").string(),0);
        check(image.size()==cv::Size(640,480),"ChArUco must be 640x480");
        auto dictionary=cv::aruco::getPredefinedDictionary(cv::aruco::DICT_5X5_50);
        auto board=createPhysicalCharucoBoard(.024,.018,dictionary);
        std::vector<std::vector<cv::Point2f>> markers;
        std::vector<int> ids,cornerIds;
        cv::aruco::detectMarkers(image,dictionary,markers,ids);
        check(ids.size()==27,"Must detect all 27 ChArUco markers");
        int n=cv::aruco::interpolateCornersCharuco(markers,ids,image,board,corners,cornerIds);
        check(n==40,"Must detect all 40 ChArUco corners");
        double maxError=0;
        for (int i=0;i<n;++i) {
            auto p=board->chessboardCorners[cornerIds[i]];
            cv::Point2f expected(68+p.x/.024f*56-.5f,72+p.y/.024f*56-.5f);
            maxError=std::max(maxError,cv::norm(expected-corners[i]));
        }
        check(maxError<1,"Generated ChArUco layout differs from physical model");
        std::cout<<"640x480 boards OK: chess 54 corners, ChArUco 27 markers/40 corners; max error "<<maxError<<"px\n";
    } catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
    return 0;
}
